import React from "react";
import Loader from "@/components/Loader";

const TestPage = () => {
  return (
    <>
      <Loader />
    </>
  );
};

export default TestPage;

import React from "react";
import RegisterANewCaseComponent from "../components/RegisterANewCaseComponent";

const RegisterNewLegalCasePage = () => {
  return (
    <>
      <RegisterANewCaseComponent />
    </>
  );
};

export default RegisterNewLegalCasePage;
